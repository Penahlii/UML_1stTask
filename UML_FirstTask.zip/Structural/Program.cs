﻿public interface IClient
{
    void method(string data);
}

public class Service
{
    public void servicemethod(string specialData) { }
}

public class Adapter
{
    private Service _service;

    public void method(string data) { }
}