﻿public interface IVisitor
{
    void visit(ConcreteElementA e);
    void visit(ConcreteElementB e);
}

public interface IElement
{
    void accept(IVisitor v);
}

public class ConcreteElementA : IElement
{
    public void accept(IVisitor v)
    {
        // accept
    }

    public void FeatureA() { }
}

public class ConcreteElementB : IElement
{
    public void accept(IVisitor v)
    {
        // accept
    }

    public void FeatureB() { }
}

public class ConcreteVisitors : IVisitor
{
    public void visit(ConcreteElementA e)
    {
        // visit Element A
    }

    public void visit(ConcreteElementB e)
    {
        // visit Element B
    }
}