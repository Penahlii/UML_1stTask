﻿public interface IBuilder
{
    void Reset();
    void BuildStepA();
    void BuildStepB();
    void BuildStepC();
}

public class Director
{
    private IBuilder _builder;
    public Director(IBuilder builder) { }

    public void ChangeBuilder(IBuilder builder) { }
    public void Make(string type) { }
}

public class ConcereteBuilder1 : IBuilder
{
          // not string
    private string _result;

    public void BuildStepA()
    {
        // Build Step A
    }

    public void BuildStepB()
    {
        // Build Step B
    }

    public void BuildStepC()
    {
        // Build Step C
    }

    public void Reset()
    {
        // reset
    }

           // not void 
    public void getResult()
    {
        // return result
    }
}

public class ConcereteBuilder2 : IBuilder
{
    // not string
    private string _result;

    public void BuildStepA()
    {
        // Build Step A
    }

    public void BuildStepB()
    {
        // Build Step B
    }

    public void BuildStepC()
    {
        // Build Step C
    }

    public void Reset()
    {
        // reset
    }

    // not void 
    public void getResult()
    {
        // return result
    }
}